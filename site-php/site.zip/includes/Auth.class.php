<?php

    class Auth{
        public function __construct(){
            
                        
        }
       
    }
?>